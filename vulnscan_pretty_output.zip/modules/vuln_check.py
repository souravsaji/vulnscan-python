# modules/vuln_check.py
def check_vulnerabilities(service, version):
    # Dummy implementation - replace with Vulners API or other in real use
    dummy_vulns = {
        "http": ["CVE-2021-1234", "CVE-2022-5678"],
        "ssh": ["CVE-2020-9999"],
        "ftp": ["CVE-2019-0001"]
    }
    return dummy_vulns.get(service.lower(), [])
