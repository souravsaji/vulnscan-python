# modules/port_scan.py
import socket

def scan_ports(target):
    ports = [21, 22, 23, 25, 53, 80, 110, 139, 143, 443, 445, 3389]
    scan_data = {}

    for port in ports:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(1)
                result = sock.connect_ex((target, port))
                if result == 0:
                    service = socket.getservbyport(port, "tcp")
                    version = "unknown"
                    scan_data[port] = {"service": service, "version": version}
        except Exception:
            continue

    return scan_data
