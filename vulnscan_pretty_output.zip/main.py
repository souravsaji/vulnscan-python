# main.py
from modules.port_scan import scan_ports
from modules.vuln_check import check_vulnerabilities
from rich.console import Console
from rich.table import Table

console = Console()

def display_results(results):
    table = Table(title="🛡️ Vulnerability Scan Results")
    table.add_column("Port", style="cyan", no_wrap=True)
    table.add_column("Service", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Vulnerabilities", style="red")

    for port, info in results.items():
        service = info.get("service", "")
        version = info.get("version", "")
        vulns = ", ".join(info.get("vulnerabilities", [])) or "None"
        table.add_row(str(port), service, version, vulns)

    console.print(table)

def main():
    target = input("Enter IP or domain to scan: ")
    scan_data = scan_ports(target)

    if not scan_data:
        console.print(f"[red]\n[!] No data returned. Check if the host is reachable: {target}\n")
        return

    for port, info in scan_data.items():
        cves = check_vulnerabilities(info["service"], info["version"])
        scan_data[port]["vulnerabilities"] = cves

    display_results(scan_data)

if __name__ == "__main__":
    main()
